import React from 'react'
import '../styles/NavBar.css'

export default () => {
    return (
        <div className="navbar">
            <h1>Find YourBike!!</h1>
        </div>
    )   
}
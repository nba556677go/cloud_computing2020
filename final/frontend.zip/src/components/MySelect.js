import React from 'react'

export default () => {
  return (
    <div className='my-select'>
      <select>
        <option>Hello</option>
        <option>World</option>
      </select>
    </div>
  )
}
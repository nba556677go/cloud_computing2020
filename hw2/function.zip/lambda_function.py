import logging
import json
import os
from pymongo import MongoClient


# Logger settings - CloudWatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Set client
#client = MongoClient('mongodb://{}:27017/'.format(os.environ['DB_HOST'] ))
try:
    print("connecting to Database...")
    client = MongoClient(os.environ['DB_HOST'],
                    username='root',
                    password='root',
                    authSource='admin',
                    authMechanism='SCRAM-SHA-1')
    logger.info("connected!")
except:
    logger.info("connection error!")
    exit()


def lambda_handler(event, context):
    resultJson = None 
    try:
        print("event: ", event['multiValueQueryStringParameters'])
        request_city = {"city" : event['multiValueQueryStringParameters']['city'][0]}
        print("request_city",  request_city)
        logger.info("logging...")
        #print("dbnames: ", client.list_database_names())
        # TODO implement
        col = client["country"]['country_info']
        print("collection set!")
        #result = col.find_one({"city" : "HAMPDEN"})
        result = col.find_one(request_city)
        print("collection found", result)
        #print(col.find())
        resultJson = {
            'statusCode': 200,
            'body': json.dumps(result)            
        }
    except Exception as error:
        resultJson = {
            'statusCode': 500,
            'body': str(error)
        }
        
    return resultJson
